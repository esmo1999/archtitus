#!/bin/bash

sudo cat <<EOF > /etc/vconsole.conf
KEYMAP=us
FONT=ter-v16b
EOF