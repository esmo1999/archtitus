#!/bin/bash

cp -r $HOME/.config/kitty $HOME/ArchTitus/dotfiles/kitty
konsave -s kde
konsave -e kde